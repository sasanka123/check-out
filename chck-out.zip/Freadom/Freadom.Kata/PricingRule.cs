﻿namespace Freadom.Kata
{
    public class PricingRule
    {
        public char Item { get; set; }

        public int UnitPrice { get; set; }

        public int? DiscountPriceUnits { get; set; }

        public int? DiscountPrice { get; set; }
    }
}
